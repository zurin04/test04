#!/bin/bash

# CryptoHub - Single Script VPS Deployment
# One command deployment for Ubuntu VPS

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log() { echo -e "${GREEN}[INFO]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; }
step() { echo -e "${BLUE}[STEP]${NC} $1"; }

echo "================================================"
echo "    CryptoHub - One-Click VPS Deployment       "
echo "================================================"

# Prerequisites check
[[ $EUID -eq 0 ]] && { error "Don't run as root. Use regular user with sudo."; exit 1; }
command -v sudo >/dev/null || { error "sudo required but not installed."; exit 1; }

# System info
step "System Information"
echo "OS: $(lsb_release -d | cut -f2)"
echo "RAM: $(free -h | awk '/^Mem:/ {print $2}')"
echo "Disk: $(df -h / | awk 'NR==2 {print $4}') available"

# Install everything
step "Installing Dependencies"
sudo apt update -y
sudo apt install -y curl wget gnupg postgresql postgresql-contrib nginx certbot python3-certbot-nginx build-essential git ufw htop

# Install Node.js 20
if ! command -v node &>/dev/null; then
    log "Installing Node.js 20..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
fi

# Install PM2
sudo npm install -g pm2 2>/dev/null || warn "PM2 already installed"

# Start services
sudo systemctl enable --now postgresql nginx

# Setup app directory
APP_DIR="/var/www/cryptohub"
step "Setting Up Application"
sudo mkdir -p $APP_DIR && sudo chown $USER:$USER $APP_DIR

# Copy files (assumes script is in project root)
if [ -f "package.json" ]; then
    cp -r . $APP_DIR/
    cd $APP_DIR
else
    error "Run this script from your CryptoHub project directory."
    exit 1
fi

# Generate credentials
step "Creating Database and Credentials"
DB_PASSWORD=$(openssl rand -base64 32)
SESSION_SECRET=$(openssl rand -hex 32)

# Setup PostgreSQL
sudo -u postgres psql << EOF
DROP DATABASE IF EXISTS cryptohub_db;
DROP USER IF EXISTS cryptohub_user;
CREATE USER cryptohub_user WITH PASSWORD '$DB_PASSWORD' SUPERUSER;
CREATE DATABASE cryptohub_db OWNER cryptohub_user;
GRANT ALL PRIVILEGES ON DATABASE cryptohub_db TO cryptohub_user;
\q
EOF

# Create environment
cat > .env << ENV
DATABASE_URL=postgresql://cryptohub_user:$DB_PASSWORD@localhost:5432/cryptohub_db
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=5000
PGHOST=localhost
PGPORT=5432
PGUSER=cryptohub_user
PGPASSWORD=$DB_PASSWORD
PGDATABASE=cryptohub_db
REPL_ID=cryptohub-production
ENV

# Install and build
step "Building Application"
npm install
export DATABASE_URL="postgresql://cryptohub_user:$DB_PASSWORD@localhost:5432/cryptohub_db"
npm run db:push
npm run build

# Configure PM2
mkdir -p logs
cat > ecosystem.config.cjs << EOF
module.exports = {
  apps: [{
    name: 'cryptohub',
    script: 'dist/index.js',
    instances: 1,
    autorestart: true,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DATABASE_URL: 'postgresql://cryptohub_user:$DB_PASSWORD@localhost:5432/cryptohub_db',
      SESSION_SECRET: '$SESSION_SECRET',
      PGHOST: 'localhost',
      PGPORT: '5432',
      PGUSER: 'cryptohub_user',
      PGPASSWORD: '$DB_PASSWORD',
      PGDATABASE: 'cryptohub_db'
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true
  }]
}
EOF

# Configure Nginx
step "Configuring Web Server"
sudo tee /etc/nginx/sites-available/cryptohub > /dev/null << 'EOF'
server {
    listen 80;
    server_name _;
    client_max_body_size 100M;
    
    # Security headers
    add_header X-Frame-Options DENY always;
    add_header X-Content-Type-Options nosniff always;
    add_header X-XSS-Protection "1; mode=block" always;
    
    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;
    
    # Static files
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        try_files $uri @proxy;
    }
    
    # Main proxy
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_connect_timeout 30s;
        proxy_send_timeout 30s;
        proxy_read_timeout 30s;
    }
    
    # Fallback
    location @proxy {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
EOF

# Enable site
sudo ln -sf /etc/nginx/sites-available/cryptohub /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx

# Start application
step "Starting Application"
pm2 delete all 2>/dev/null || true
pm2 start ecosystem.config.cjs
pm2 save
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp $HOME

# Configure security
step "Setting Up Security"
sudo ufw --force enable
sudo ufw allow 22,80,443/tcp

# Verify deployment
step "Verifying Deployment"
sleep 10

if pm2 list | grep -q "cryptohub.*online"; then
    log "✓ Application running"
    
    if curl -f -s http://localhost:5000 >/dev/null 2>&1; then
        log "✓ Application responding"
    else
        warn "⚠ Application not responding - check logs: pm2 logs cryptohub"
    fi
else
    error "✗ Application failed to start"
    echo "Logs:"
    pm2 logs cryptohub --lines 10
    exit 1
fi

# Final status
echo ""
echo "🎉 Deployment Complete!"
echo "======================="
echo ""
echo "🔗 Access: http://$(curl -s ipecho.net/plain || echo 'YOUR_SERVER_IP')"
echo "📊 Status: pm2 status cryptohub"
echo "📝 Logs: pm2 logs cryptohub"
echo ""
echo "📋 Quick Commands:"
echo "  pm2 restart cryptohub    # Restart app"
echo "  pm2 logs cryptohub       # View logs"
echo "  sudo systemctl status nginx  # Check web server"
echo ""
echo "🔐 Database Info:"
echo "  User: cryptohub_user"
echo "  Database: cryptohub_db"
echo "  Password: [saved in .env]"
echo ""
echo "🚀 Next Steps:"
echo "  1. Point your domain to this server"
echo "  2. Set up SSL: sudo certbot --nginx -d yourdomain.com"
echo "  3. Create admin user via web interface"
echo ""

# Troubleshooting function for 502 errors
cat > fix-502.sh << 'SCRIPT'
#!/bin/bash
echo "502 Bad Gateway Fix"
echo "=================="

# Check PM2
if pm2 list | grep -q "cryptohub.*online"; then
    echo "✓ PM2 process running"
else
    echo "✗ PM2 process not running - starting..."
    pm2 start cryptohub
    sleep 5
fi

# Check HTTP response
if curl -f -s http://localhost:5000 >/dev/null 2>&1; then
    echo "✓ App responding on port 5000"
else
    echo "✗ App not responding - checking logs..."
    pm2 logs cryptohub --lines 20
    exit 1
fi

# Check Nginx
if sudo nginx -t >/dev/null 2>&1; then
    echo "✓ Nginx config valid"
else
    echo "✗ Nginx config error"
    sudo nginx -t
    exit 1
fi

# Check services
if sudo systemctl is-active --quiet nginx; then
    echo "✓ Nginx running"
else
    echo "✗ Nginx not running - starting..."
    sudo systemctl start nginx
fi

echo "✓ 502 issues should be resolved!"
SCRIPT

chmod +x fix-502.sh
log "Created fix-502.sh for troubleshooting"

echo "✅ Single-script deployment completed successfully!"