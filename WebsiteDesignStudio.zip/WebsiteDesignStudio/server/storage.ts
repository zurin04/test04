import {
  users,
  posts,
  comments,
  likes,
  savedPosts,
  follows,
  announcements,
  siteSettings,
  notifications,
  type User,
  type UpsertUser,
  type InsertPost,
  type Post,
  type PostWithUser,
  type PostWithDetails,
  type InsertComment,
  type Comment,
  type SavedPost,
  type Announcement,
  type InsertAnnouncement,
  type SiteSetting,
  type InsertSiteSetting,
  type Notification,
  type InsertNotification,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc, sql, and, or, ilike, inArray } from "drizzle-orm";

export interface IStorage {
  // User operations - mandatory for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByWallet(walletAddress: string): Promise<User | undefined>;
  createUser(user: UpsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<UpsertUser>): Promise<User | undefined>;
  updateUserRole(id: string, role: string): Promise<User | undefined>;
  getAllUsers(options?: { limit?: number; offset?: number }): Promise<User[]>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Post operations
  createPost(post: InsertPost): Promise<Post>;
  getPosts(options?: {
    category?: string;
    userId?: string;
    search?: string;
    sortBy?: 'recent' | 'popular' | 'trending';
    limit?: number;
    offset?: number;
  }): Promise<PostWithDetails[]>;
  getPostById(id: number, userId?: string): Promise<PostWithDetails | undefined>;
  updatePost(id: number, updates: Partial<InsertPost>): Promise<Post | undefined>;
  deletePost(id: number): Promise<boolean>;
  
  // Post interactions
  toggleLike(userId: string, postId: number): Promise<boolean>;
  toggleSave(userId: string, postId: number): Promise<boolean>;
  getSavedPosts(userId: string, options?: {
    limit?: number;
    offset?: number;
  }): Promise<PostWithDetails[]>;
  
  // Comments
  createComment(comment: InsertComment): Promise<Comment>;
  getCommentsByPostId(postId: number): Promise<Array<Comment & { user: User }>>;
  
  // Follows
  toggleFollow(followerId: string, followingId: string): Promise<boolean>;
  getFollowing(userId: string): Promise<User[]>;
  getFollowers(userId: string): Promise<User[]>;
  
  // Announcements
  createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement>;
  getActiveAnnouncements(): Promise<Announcement[]>;
  updateAnnouncement(id: number, updates: Partial<InsertAnnouncement>): Promise<Announcement | undefined>;
  deactivateAnnouncement(id: number): Promise<boolean>;
  
  // Search and stats
  searchPosts(query: string, options?: {
    category?: string;
    limit?: number;
    offset?: number;
  }): Promise<PostWithDetails[]>;
  getUserStats(userId: string): Promise<{
    postsCount: number;
    savedCount: number;
    followingCount: number;
    followersCount: number;
  }>;
  
  // Site settings
  getSiteSettings(): Promise<SiteSetting[]>;
  getSiteSetting(key: string): Promise<SiteSetting | undefined>;
  updateSiteSetting(key: string, value: string): Promise<SiteSetting | undefined>;
  
  // Notifications
  createNotification(notification: InsertNotification): Promise<Notification>;
  getNotifications(userId: string, options?: {
    limit?: number;
    offset?: number;
    unreadOnly?: boolean;
  }): Promise<Notification[]>;
  markNotificationAsRead(id: number): Promise<boolean>;
  markAllNotificationsAsRead(userId: string): Promise<boolean>;
  deleteNotification(id: number): Promise<boolean>;
  getUnreadNotificationCount(userId: string): Promise<number>;
}

export class DatabaseStorage implements IStorage {
  // User operations - mandatory for Replit Auth
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async getUserByWallet(walletAddress: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.walletAddress, walletAddress));
    return user;
  }

  async createUser(userData: UpsertUser): Promise<User> {
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }

  async updateUser(id: string, updates: Partial<UpsertUser>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserRole(id: string, role: string): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ role, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async getAllUsers(options: { limit?: number; offset?: number } = {}): Promise<User[]> {
    const { limit = 50, offset = 0 } = options;
    return await db
      .select()
      .from(users)
      .orderBy(desc(users.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Post operations
  async createPost(post: InsertPost): Promise<Post> {
    const [newPost] = await db.insert(posts).values(post).returning();
    return newPost;
  }

  async getPosts(options: {
    category?: string;
    userId?: string;
    search?: string;
    sortBy?: 'recent' | 'popular' | 'trending';
    limit?: number;
    offset?: number;
  } = {}): Promise<PostWithDetails[]> {
    const {
      category,
      userId,
      search,
      sortBy = 'recent',
      limit = 20,
      offset = 0,
    } = options;

    let query = db
      .select({
        post: posts,
        user: users,
        isLiked: sql<boolean>`CASE WHEN ${likes.userId} IS NOT NULL THEN true ELSE false END`,
        isSaved: sql<boolean>`CASE WHEN ${savedPosts.userId} IS NOT NULL THEN true ELSE false END`,
      })
      .from(posts)
      .innerJoin(users, eq(posts.userId, users.id))
      .leftJoin(
        likes,
        and(eq(likes.postId, posts.id), userId ? eq(likes.userId, userId) : undefined)
      )
      .leftJoin(
        savedPosts,
        and(eq(savedPosts.postId, posts.id), userId ? eq(savedPosts.userId, userId) : undefined)
      )
      .where(
        and(
          eq(posts.isActive, true),
          category ? eq(posts.category, category) : undefined,
          search ? or(
            ilike(posts.title, `%${search}%`),
            ilike(posts.content, `%${search}%`)
          ) : undefined
        )
      );

    // Apply sorting and execute query
    let results;
    switch (sortBy) {
      case 'popular':
        results = await query
          .orderBy(desc(posts.likesCount), desc(posts.createdAt))
          .limit(limit)
          .offset(offset);
        break;
      case 'trending':
        results = await query
          .orderBy(
            desc(sql`(${posts.likesCount} + ${posts.commentsCount}) / EXTRACT(EPOCH FROM (NOW() - ${posts.createdAt})) * 86400`),
            desc(posts.createdAt)
          )
          .limit(limit)
          .offset(offset);
        break;
      default:
        results = await query
          .orderBy(desc(posts.createdAt))
          .limit(limit)
          .offset(offset);
    }

    // Get comments for each post
    const postsWithComments = await Promise.all(
      results.map(async (result) => {
        const comments = await this.getCommentsByPostId(result.post.id);
        return {
          ...result.post,
          user: result.user,
          isLiked: result.isLiked,
          isSaved: result.isSaved,
          comments,
        } as PostWithDetails;
      })
    );

    return postsWithComments;
  }

  async getPostById(id: number, userId?: string): Promise<PostWithDetails | undefined> {
    const [result] = await db
      .select({
        post: posts,
        user: users,
        isLiked: sql<boolean>`CASE WHEN ${likes.userId} IS NOT NULL THEN true ELSE false END`,
        isSaved: sql<boolean>`CASE WHEN ${savedPosts.userId} IS NOT NULL THEN true ELSE false END`,
      })
      .from(posts)
      .innerJoin(users, eq(posts.userId, users.id))
      .leftJoin(
        likes,
        and(eq(likes.postId, posts.id), userId ? eq(likes.userId, userId) : undefined)
      )
      .leftJoin(
        savedPosts,
        and(eq(savedPosts.postId, posts.id), userId ? eq(savedPosts.userId, userId) : undefined)
      )
      .where(and(eq(posts.id, id), eq(posts.isActive, true)));

    if (!result) return undefined;

    const comments = await this.getCommentsByPostId(id);

    return {
      ...result.post,
      user: result.user,
      isLiked: result.isLiked,
      isSaved: result.isSaved,
      comments,
    } as PostWithDetails;
  }

  async updatePost(id: number, updates: Partial<InsertPost>): Promise<Post | undefined> {
    const [updatedPost] = await db
      .update(posts)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(posts.id, id))
      .returning();
    return updatedPost;
  }

  async deletePost(id: number): Promise<boolean> {
    const [result] = await db
      .update(posts)
      .set({ isActive: false })
      .where(eq(posts.id, id))
      .returning();
    return !!result;
  }

  // Post interactions
  async toggleLike(userId: string, postId: number): Promise<boolean> {
    const [existingLike] = await db
      .select()
      .from(likes)
      .where(and(eq(likes.userId, userId), eq(likes.postId, postId)));

    if (existingLike) {
      // Unlike
      await db
        .delete(likes)
        .where(and(eq(likes.userId, userId), eq(likes.postId, postId)));
      
      await db
        .update(posts)
        .set({ likesCount: sql`${posts.likesCount} - 1` })
        .where(eq(posts.id, postId));
      
      return false;
    } else {
      // Like
      await db.insert(likes).values({ userId, postId });
      
      await db
        .update(posts)
        .set({ likesCount: sql`${posts.likesCount} + 1` })
        .where(eq(posts.id, postId));
      
      return true;
    }
  }

  async toggleSave(userId: string, postId: number): Promise<boolean> {
    const [existingSave] = await db
      .select()
      .from(savedPosts)
      .where(and(eq(savedPosts.userId, userId), eq(savedPosts.postId, postId)));

    if (existingSave) {
      // Unsave
      await db
        .delete(savedPosts)
        .where(and(eq(savedPosts.userId, userId), eq(savedPosts.postId, postId)));
      return false;
    } else {
      // Save
      await db.insert(savedPosts).values({ userId, postId });
      return true;
    }
  }

  async getSavedPosts(userId: string, options: {
    limit?: number;
    offset?: number;
  } = {}): Promise<PostWithDetails[]> {
    const { limit = 20, offset = 0 } = options;

    const results = await db
      .select({
        post: posts,
        user: users,
        savedAt: savedPosts.createdAt,
      })
      .from(savedPosts)
      .innerJoin(posts, eq(savedPosts.postId, posts.id))
      .innerJoin(users, eq(posts.userId, users.id))
      .where(and(eq(savedPosts.userId, userId), eq(posts.isActive, true)))
      .orderBy(desc(savedPosts.createdAt))
      .limit(limit)
      .offset(offset);

    const postsWithComments = await Promise.all(
      results.map(async (result) => {
        const comments = await this.getCommentsByPostId(result.post.id);
        return {
          ...result.post,
          user: result.user,
          isLiked: false, // We'd need to check this separately for saved posts view
          isSaved: true,
          comments,
        } as PostWithDetails;
      })
    );

    return postsWithComments;
  }

  // Comments
  async createComment(comment: InsertComment): Promise<Comment> {
    const [newComment] = await db.insert(comments).values(comment).returning();
    
    // Update comment count
    await db
      .update(posts)
      .set({ commentsCount: sql`${posts.commentsCount} + 1` })
      .where(eq(posts.id, comment.postId));
    
    return newComment;
  }

  async getCommentsByPostId(postId: number): Promise<Array<Comment & { user: User }>> {
    const results = await db
      .select({
        comment: comments,
        user: users,
      })
      .from(comments)
      .innerJoin(users, eq(comments.userId, users.id))
      .where(eq(comments.postId, postId))
      .orderBy(asc(comments.createdAt));

    return results.map(result => ({
      ...result.comment,
      user: result.user,
    }));
  }

  // Follows
  async toggleFollow(followerId: string, followingId: string): Promise<boolean> {
    if (followerId === followingId) return false;

    const [existingFollow] = await db
      .select()
      .from(follows)
      .where(and(eq(follows.followerId, followerId), eq(follows.followingId, followingId)));

    if (existingFollow) {
      // Unfollow
      await db
        .delete(follows)
        .where(and(eq(follows.followerId, followerId), eq(follows.followingId, followingId)));
      return false;
    } else {
      // Follow
      await db.insert(follows).values({ followerId, followingId });
      return true;
    }
  }

  async getFollowing(userId: string): Promise<User[]> {
    const results = await db
      .select({ user: users })
      .from(follows)
      .innerJoin(users, eq(follows.followingId, users.id))
      .where(eq(follows.followerId, userId));

    return results.map(result => result.user);
  }

  async getFollowers(userId: string): Promise<User[]> {
    const results = await db
      .select({ user: users })
      .from(follows)
      .innerJoin(users, eq(follows.followerId, users.id))
      .where(eq(follows.followingId, userId));

    return results.map(result => result.user);
  }

  // Announcements
  async createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement> {
    const [newAnnouncement] = await db.insert(announcements).values(announcement).returning();
    return newAnnouncement;
  }

  async getActiveAnnouncements(): Promise<Announcement[]> {
    return await db
      .select()
      .from(announcements)
      .where(eq(announcements.isActive, true))
      .orderBy(desc(announcements.createdAt));
  }

  async updateAnnouncement(id: number, updates: Partial<InsertAnnouncement>): Promise<Announcement | undefined> {
    const [updatedAnnouncement] = await db
      .update(announcements)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(announcements.id, id))
      .returning();
    return updatedAnnouncement;
  }

  async deactivateAnnouncement(id: number): Promise<boolean> {
    const [result] = await db
      .update(announcements)
      .set({ isActive: false })
      .where(eq(announcements.id, id))
      .returning();
    return !!result;
  }

  // Search and stats
  async searchPosts(query: string, options: {
    category?: string;
    limit?: number;
    offset?: number;
  } = {}): Promise<PostWithDetails[]> {
    return this.getPosts({ ...options, search: query });
  }

  async getUserStats(userId: string): Promise<{
    postsCount: number;
    savedCount: number;
    followingCount: number;
    followersCount: number;
  }> {
    const [postsCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(posts)
      .where(and(eq(posts.userId, userId), eq(posts.isActive, true)));

    const [savedCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(savedPosts)
      .where(eq(savedPosts.userId, userId));

    const [followingCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(follows)
      .where(eq(follows.followerId, userId));

    const [followersCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(follows)
      .where(eq(follows.followingId, userId));

    return {
      postsCount: postsCount.count,
      savedCount: savedCount.count,
      followingCount: followingCount.count,
      followersCount: followersCount.count,
    };
  }

  // Site settings
  async getSiteSettings(): Promise<SiteSetting[]> {
    return await db.select().from(siteSettings).orderBy(asc(siteSettings.key));
  }

  async getSiteSetting(key: string): Promise<SiteSetting | undefined> {
    const [setting] = await db.select().from(siteSettings).where(eq(siteSettings.key, key));
    return setting;
  }

  async updateSiteSetting(key: string, value: string): Promise<SiteSetting | undefined> {
    const [setting] = await db
      .insert(siteSettings)
      .values({ key, value, updatedAt: new Date() })
      .onConflictDoUpdate({
        target: siteSettings.key,
        set: { value, updatedAt: new Date() },
      })
      .returning();
    return setting;
  }

  // Notifications
  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db.insert(notifications).values(notification).returning();
    return newNotification;
  }

  async getNotifications(userId: string, options: {
    limit?: number;
    offset?: number;
    unreadOnly?: boolean;
  } = {}): Promise<Notification[]> {
    const { limit = 50, offset = 0, unreadOnly = false } = options;
    
    const conditions = [eq(notifications.userId, userId)];
    if (unreadOnly) {
      conditions.push(eq(notifications.isRead, false));
    }
    
    return await db.select()
      .from(notifications)
      .where(and(...conditions))
      .orderBy(desc(notifications.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async markNotificationAsRead(id: number): Promise<boolean> {
    const result = await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id))
      .returning();
    
    return result.length > 0;
  }

  async markAllNotificationsAsRead(userId: string): Promise<boolean> {
    const result = await db
      .update(notifications)
      .set({ isRead: true })
      .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)))
      .returning();
    
    return result.length > 0;
  }

  async deleteNotification(id: number): Promise<boolean> {
    const result = await db.delete(notifications).where(eq(notifications.id, id)).returning();
    return result.length > 0;
  }

  async getUnreadNotificationCount(userId: string): Promise<number> {
    const [result] = await db
      .select({ count: sql<number>`count(*)` })
      .from(notifications)
      .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)));
    
    return result.count;
  }
}

export const storage = new DatabaseStorage();
