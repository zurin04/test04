import { storage } from "./storage";
import type { InsertNotification } from "@shared/schema";

export class NotificationService {
  static async createLikeNotification(
    postId: number, 
    postOwnerId: string, 
    likedByUserId: string,
    likedByUserName: string
  ) {
    // Don't notify if user likes their own post
    if (postOwnerId === likedByUserId) return;

    const notification: InsertNotification = {
      userId: postOwnerId,
      type: 'like',
      title: 'New Like',
      message: `${likedByUserName} liked your post`,
      relatedPostId: postId,
      relatedUserId: likedByUserId,
    };

    await storage.createNotification(notification);
  }

  static async createCommentNotification(
    postId: number,
    postOwnerId: string,
    commenterId: string,
    commenterName: string
  ) {
    // Don't notify if user comments on their own post
    if (postOwnerId === commenterId) return;

    const notification: InsertNotification = {
      userId: postOwnerId,
      type: 'comment',
      title: 'New Comment',
      message: `${commenterName} commented on your post`,
      relatedPostId: postId,
      relatedUserId: commenterId,
    };

    await storage.createNotification(notification);
  }

  static async createFollowNotification(
    followedUserId: string,
    followerId: string,
    followerName: string
  ) {
    const notification: InsertNotification = {
      userId: followedUserId,
      type: 'follow',
      title: 'New Follower',
      message: `${followerName} started following you`,
      relatedUserId: followerId,
    };

    await storage.createNotification(notification);
  }

  static async createPostNotification(
    postId: number,
    authorId: string,
    authorName: string,
    postTitle: string,
    followerIds: string[]
  ) {
    // Create notifications for all followers
    const notifications: InsertNotification[] = followerIds.map(followerId => ({
      userId: followerId,
      type: 'post',
      title: 'New Post',
      message: `${authorName} published a new post: ${postTitle}`,
      relatedPostId: postId,
      relatedUserId: authorId,
    }));

    // Create all notifications in parallel
    await Promise.all(
      notifications.map(notification => storage.createNotification(notification))
    );
  }
}