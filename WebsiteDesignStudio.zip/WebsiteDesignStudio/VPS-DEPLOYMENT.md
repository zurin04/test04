# CryptoHub VPS Deployment Guide

This guide will help you deploy CryptoHub to your own VPS server in production.

## Prerequisites

- Ubuntu 20.04+ VPS with at least 2GB RAM
- Root or sudo access
- Domain name pointed to your VPS (optional, for SSL)

## Quick Deployment

1. **Upload your project to the VPS:**
   ```bash
   # Option 1: Using git (recommended)
   git clone <your-repository-url>
   cd cryptohub
   
   # Option 2: Upload files via SCP
   scp -r ./cryptohub user@your-server-ip:/home/user/
   ```

2. **Run the deployment script:**
   ```bash
   chmod +x deploy-vps.sh
   ./deploy-vps.sh
   ```

3. **The script will automatically:**
   - Install Node.js, PostgreSQL, Nginx, and other dependencies
   - Create a secure database with random credentials
   - Build and configure your application
   - Set up PM2 for process management
   - Configure Nginx as a reverse proxy
   - Set up security and firewall rules

## Post-Deployment

### Access Your Application
- **Local:** http://localhost:5000
- **Public:** http://your-server-ip

### Set Up SSL (Optional)
```bash
./manage.sh ssl yourdomain.com
```

### Create Admin User
1. Visit your application in a web browser
2. Sign up with your email
3. The first user is automatically made admin, or run:
   ```bash
   # Connect to database and update user role
   sudo -u postgres psql cryptohub_db
   UPDATE users SET role = 'admin' WHERE email = 'your-email@example.com';
   ```

## Management Commands

The deployment creates a management script with useful commands:

```bash
# Application management
./manage.sh start      # Start the application
./manage.sh stop       # Stop the application
./manage.sh restart    # Restart the application
./manage.sh status     # Check status
./manage.sh logs       # View logs

# Maintenance
./manage.sh backup     # Create database backup
./manage.sh restore    # Restore from backup
./manage.sh update     # Safe update from git
./manage.sh health     # Run health check
./manage.sh monitor    # Real-time monitoring

# SSL setup
./manage.sh ssl yourdomain.com
```

## File Locations

- **Application:** `/var/www/cryptohub/`
- **Logs:** `/var/www/cryptohub/logs/`
- **Backups:** `/var/backups/cryptohub/`
- **Config:** `/var/www/cryptohub/.env`
- **Nginx:** `/etc/nginx/sites-available/cryptohub`

## Environment Variables

The deployment automatically creates a `.env` file with:

```env
DATABASE_URL=postgresql://cryptohub_user:password@localhost:5432/cryptohub_db
SESSION_SECRET=random-session-secret
NODE_ENV=production
PORT=5000
PGHOST=localhost
PGPORT=5432
PGUSER=cryptohub_user
PGPASSWORD=random-password
PGDATABASE=cryptohub_db
```

## Security Features

- Firewall configured (SSH, HTTP, HTTPS only)
- Secure database with random credentials
- Nginx security headers
- PM2 process management with auto-restart
- Automatic SSL certificate renewal

## Monitoring

### Check Application Status
```bash
pm2 status cryptohub
pm2 logs cryptohub
```

### Check System Health
```bash
./manage.sh health
```

### Real-time Monitoring
```bash
./manage.sh monitor
```

## Troubleshooting

### Application Won't Start
```bash
# Check logs
pm2 logs cryptohub

# Check configuration
cat .env

# Restart application
./manage.sh restart
```

### Database Issues
```bash
# Test database connection
sudo -u postgres psql cryptohub_db

# Check database logs
sudo journalctl -u postgresql
```

### Nginx Issues
```bash
# Test configuration
sudo nginx -t

# Check logs
sudo tail -f /var/log/nginx/error.log
```

## Updates

To update your application:

```bash
# Safe update (with automatic backup)
./manage.sh update

# Manual update
git pull
npm install
npm run build
./manage.sh restart
```

## Backup and Restore

### Create Backup
```bash
./manage.sh backup
```

### Restore from Backup
```bash
./manage.sh restore /var/backups/cryptohub/backup_20250101_120000.sql
```

## Performance Optimization

For better performance on production:

1. **Increase PM2 instances:**
   ```bash
   # Edit ecosystem.config.cjs
   instances: 'max'  # Use all CPU cores
   ```

2. **Enable Nginx caching:**
   ```bash
   # Add to Nginx config
   proxy_cache_path /var/cache/nginx levels=1:2 keys_zone=app_cache:10m;
   ```

3. **Set up database connection pooling:**
   - Already configured in the application

## Support

If you encounter issues:

1. Check the application logs: `pm2 logs cryptohub`
2. Run health check: `./manage.sh health`
3. Check system resources: `htop`, `df -h`
4. Review Nginx logs: `sudo tail -f /var/log/nginx/error.log`

## Security Notes

- Change default passwords after deployment
- Keep your system updated: `sudo apt update && sudo apt upgrade`
- Monitor logs regularly
- Set up automated backups
- Use strong SSL certificates
- Configure proper firewall rules

The deployment script sets up a production-ready environment with security best practices, but always review and adjust settings based on your specific requirements.