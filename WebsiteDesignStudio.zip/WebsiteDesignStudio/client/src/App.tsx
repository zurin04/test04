import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ThemeProvider";
import { useAuth } from "@/hooks/useAuth";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/Landing";
import Home from "@/pages/Home";
import Profile from "@/pages/Profile";
import Auth from "@/pages/AuthNew";
import AdminDashboard from "@/pages/AdminDashboard";
import Guidelines from "@/pages/Guidelines";
import FAQ from "@/pages/FAQ";
import Support from "@/pages/Support";
import APIDocumentation from "@/pages/APIDocumentation";
import Tutorials from "@/pages/Tutorials";
import Blog from "@/pages/Blog";
import Settings from "@/pages/Settings";

function Router() {
  const { isAuthenticated, isLoading, user } = useAuth();

  return (
    <Switch>
      <Route path="/auth" component={Auth} />
      {isLoading ? (
        <Route path="/" component={Landing} />
      ) : !isAuthenticated ? (
        <>
          <Route path="/" component={Landing} />
          <Route path="/guidelines" component={Guidelines} />
          <Route path="/faq" component={FAQ} />
          <Route path="/support" component={Support} />
          <Route path="/api-docs" component={APIDocumentation} />
          <Route path="/tutorials" component={Tutorials} />
          <Route path="/blog" component={Blog} />
          <Route component={() => <Auth />} />
        </>
      ) : (
        <>
          <Route path="/" component={Home} />
          <Route path="/profile/:userId" component={Profile} />
          <Route path="/guidelines" component={Guidelines} />
          <Route path="/faq" component={FAQ} />
          <Route path="/support" component={Support} />
          <Route path="/api-docs" component={APIDocumentation} />
          <Route path="/tutorials" component={Tutorials} />
          <Route path="/blog" component={Blog} />
          <Route path="/settings" component={Settings} />
          {user?.role === "admin" && (
            <Route path="/admin" component={AdminDashboard} />
          )}
        </>
      )}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
