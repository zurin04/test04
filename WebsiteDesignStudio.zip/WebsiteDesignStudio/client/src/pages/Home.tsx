import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import Navigation from "@/components/Navigation";
import Sidebar from "@/components/Sidebar";
import PostCard from "@/components/PostCard";
import CreatePostModal from "@/components/CreatePostModal";
import AnnouncementBanner from "@/components/AnnouncementBanner";
import ActivityFeed from "@/components/ActivityFeed";
import OnboardingTour, { useOnboarding } from "@/components/OnboardingTour";
import SiteFooter from "@/components/SiteFooter";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Loader2, Activity, FileText } from "lucide-react";
import type { PostWithDetails } from "@shared/schema";

export default function Home() {
  const { user } = useAuth();
  const [sortBy, setSortBy] = useState<'recent' | 'popular' | 'trending'>('recent');
  const [category, setCategory] = useState<string>('');
  const [search, setSearch] = useState('');
  const [searchInput, setSearchInput] = useState('');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('posts');
  
  // Check if user can create posts
  const canCreatePosts = user && (user as any)?.role !== "user";
  
  // Onboarding tour hook
  const { 
    shouldShowOnboarding, 
    closeOnboarding, 
    completeOnboarding 
  } = useOnboarding();

  // Get search query from URL
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const searchParam = urlParams.get('search');
    if (searchParam) {
      setSearch(searchParam);
      setSearchInput(searchParam);
    }
  }, []);

  const { data: posts = [], isLoading, refetch } = useQuery({
    queryKey: ['/api/posts', { sortBy, category, search }],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (sortBy) params.append('sortBy', sortBy);
      if (category) params.append('category', category);
      if (search) params.append('search', search);
      
      const response = await fetch(`/api/posts?${params.toString()}`, {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch posts');
      }
      
      return response.json() as Promise<PostWithDetails[]>;
    },
  });

  const handleSearch = () => {
    setSearch(searchInput);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation onCreatePost={canCreatePosts ? () => setIsCreateModalOpen(true) : undefined} />
      <AnnouncementBanner />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <Sidebar 
            onCreatePost={canCreatePosts ? () => setIsCreateModalOpen(true) : undefined}
            selectedCategory={category}
            onCategoryChange={setCategory}
          />
          
          <div className="lg:col-span-3">
            {/* Search and Filter Bar */}
            <div className="bg-card rounded-xl shadow-lg p-6 mb-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0 gap-4">
                {/* Search */}
                <div className="flex-1 max-w-lg">
                  <div className="relative">
                    <Input
                      type="text"
                      placeholder="Search testnets, guides, airdrops..."
                      value={searchInput}
                      onChange={(e) => setSearchInput(e.target.value)}
                      onKeyPress={handleKeyPress}
                      className="pl-10"
                    />
                    <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                    <Button 
                      onClick={handleSearch}
                      variant="ghost"
                      size="sm"
                      className="absolute right-2 top-1/2 transform -translate-y-1/2"
                    >
                      Search
                    </Button>
                  </div>
                </div>

                {/* Sort and Filter Controls */}
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium">Sort by:</span>
                    <Select value={sortBy} onValueChange={(value: 'recent' | 'popular' | 'trending') => setSortBy(value)}>
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="recent">Recent</SelectItem>
                        <SelectItem value="popular">Popular</SelectItem>
                        <SelectItem value="trending">Trending</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            </div>

            {/* Posts Feed */}
            <div className="space-y-6">
              {isLoading ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="w-8 h-8 animate-spin text-primary" />
                </div>
              ) : posts.length === 0 ? (
                <div className="text-center py-12">
                  <h3 className="text-lg font-semibold text-muted-foreground mb-2">No posts found</h3>
                  <p className="text-muted-foreground">
                    {search || category ? 'Try adjusting your search or filters' : 'Be the first to create a post!'}
                  </p>
                  <Button 
                    onClick={() => setIsCreateModalOpen(true)}
                    className="mt-4 bg-crypto-gradient hover:opacity-90"
                  >
                    Create Post
                  </Button>
                </div>
              ) : (
                posts.map((post) => (
                  <PostCard 
                    key={post.id} 
                    post={post} 
                    onUpdate={refetch}
                  />
                ))
              )}
            </div>

            {/* Load More Button */}
            {posts.length > 0 && posts.length % 20 === 0 && (
              <div className="text-center mt-8">
                <Button variant="outline" className="px-8 py-3">
                  Load More Posts
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      <SiteFooter />

      {/* Create Post Modal - Only for admin and creator roles */}
      {canCreatePosts && (
        <CreatePostModal 
          isOpen={isCreateModalOpen}
          onClose={() => setIsCreateModalOpen(false)}
          onSuccess={() => {
            setIsCreateModalOpen(false);
            refetch();
          }}
        />
      )}
    </div>
  );
}
