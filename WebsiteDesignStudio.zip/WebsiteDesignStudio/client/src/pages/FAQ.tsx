import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Link } from "wouter";
import { HelpCircle, ArrowLeft } from "lucide-react";

export default function FAQ() {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <Link href="/">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          <h1 className="text-3xl font-bold mb-4">Frequently Asked Questions</h1>
          <p className="text-xl text-muted-foreground">
            Everything you need to know about CryptoHub
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <HelpCircle className="w-5 h-5 mr-2 text-crypto-blue" />
              Common Questions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger>What is CryptoHub?</AccordionTrigger>
                <AccordionContent>
                  CryptoHub is a community platform where crypto enthusiasts share knowledge about testnets, 
                  node setups, social tasks, and airdrop opportunities. We provide a safe space for learning 
                  and discovering new opportunities in the crypto space.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-2">
                <AccordionTrigger>How do I participate in testnets?</AccordionTrigger>
                <AccordionContent>
                  Browse our testnet category for step-by-step guides. Each post includes instructions, 
                  requirements, and links to official resources. Always verify information with official 
                  project sources before participating.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-3">
                <AccordionTrigger>Are the airdrop opportunities legitimate?</AccordionTrigger>
                <AccordionContent>
                  Our community focuses on sharing verified opportunities from established projects. 
                  However, always do your own research and never share private keys or seed phrases. 
                  Report any suspicious content to our moderation team.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-4">
                <AccordionTrigger>How do I create quality posts?</AccordionTrigger>
                <AccordionContent>
                  Include clear step-by-step instructions, verify all information, add relevant screenshots, 
                  and mention any requirements or deadlines. Check our Community Guidelines for detailed 
                  content standards.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-5">
                <AccordionTrigger>Can I share referral links?</AccordionTrigger>
                <AccordionContent>
                  Referral links are allowed but must be clearly disclosed. Focus on providing value 
                  first and always mention if you receive benefits from referrals.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-6">
                <AccordionTrigger>How do I report inappropriate content?</AccordionTrigger>
                <AccordionContent>
                  Use the report button on any post or comment, or contact our moderation team directly. 
                  We take community safety seriously and review all reports promptly.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-7">
                <AccordionTrigger>Is there a mobile app?</AccordionTrigger>
                <AccordionContent>
                  Currently, CryptoHub is available as a responsive web application that works great on 
                  mobile devices. A dedicated mobile app may be considered for future development.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-8">
                <AccordionTrigger>How do I connect my wallet?</AccordionTrigger>
                <AccordionContent>
                  Wallet connection features are being developed. Currently, you can sign in using 
                  Replit Auth or create an account with email. Web3 authentication will be available soon.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </CardContent>
        </Card>

        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Still have questions?</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-4">
              Can't find what you're looking for? Reach out to our community support team.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button variant="outline" className="flex-1">
                Contact Support
              </Button>
              <Button variant="outline" className="flex-1">
                Join Discord
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}