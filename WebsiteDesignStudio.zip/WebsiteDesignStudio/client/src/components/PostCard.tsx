import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  Bookmark, 
  MoreHorizontal,
  Send
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { PostWithDetails } from "@shared/schema";

interface PostCardProps {
  post: PostWithDetails;
  onUpdate: () => void;
}

const categoryStyles = {
  testnets: { bg: 'bg-crypto-blue', text: 'text-white', emoji: '🧪' },
  'node-setup': { bg: 'bg-crypto-cyan', text: 'text-white', emoji: '🖥️' },
  'social-tasks': { bg: 'bg-crypto-emerald', text: 'text-white', emoji: '📱' },
  airdrops: { bg: 'bg-crypto-purple', text: 'text-white', emoji: '🎁' },
};

export default function PostCard({ post, onUpdate }: PostCardProps) {
  const [showComments, setShowComments] = useState(false);
  const [newComment, setNewComment] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const categoryStyle = categoryStyles[post.category as keyof typeof categoryStyles] || 
    { bg: 'bg-muted', text: 'text-foreground', emoji: '📝' };

  // Like mutation
  const likeMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('POST', `/api/posts/${post.id}/like`);
    },
    onSuccess: () => {
      onUpdate();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to toggle like",
        variant: "destructive",
      });
    },
  });

  // Save mutation
  const saveMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('POST', `/api/posts/${post.id}/save`);
    },
    onSuccess: () => {
      onUpdate();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to toggle save",
        variant: "destructive",
      });
    },
  });

  // Comment mutation
  const commentMutation = useMutation({
    mutationFn: async (content: string) => {
      await apiRequest('POST', `/api/posts/${post.id}/comments`, { content });
    },
    onSuccess: () => {
      setNewComment("");
      onUpdate();
      toast({
        title: "Success",
        description: "Comment added successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to add comment",
        variant: "destructive",
      });
    },
  });

  const handleLike = () => {
    likeMutation.mutate();
  };

  const handleSave = () => {
    saveMutation.mutate();
  };

  const handleComment = () => {
    if (newComment.trim()) {
      commentMutation.mutate(newComment.trim());
    }
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: post.title,
        text: post.content.substring(0, 100) + '...',
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link copied",
        description: "Post link copied to clipboard",
      });
    }
  };

  return (
    <Card className="shadow-lg hover:shadow-xl transition-all duration-300">
      <CardContent className="p-6">
        <div className="flex items-start space-x-4">
          {/* User Avatar */}
          <Avatar className="w-12 h-12 flex-shrink-0">
            <AvatarImage src={post.user.profileImageUrl || ""} alt={post.user.firstName || "User"} />
            <AvatarFallback>
              {post.user.firstName?.[0] || post.user.email?.[0] || "U"}
            </AvatarFallback>
          </Avatar>
          
          <div className="flex-1 min-w-0">
            {/* Post Header */}
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-2">
                <h4 className="font-semibold text-foreground">
                  {post.user.firstName || "Anonymous User"}
                </h4>
                <Badge className={cn(categoryStyle.bg, categoryStyle.text, "text-xs")}>
                  {categoryStyle.emoji} {post.category.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </Badge>
                <span className="text-muted-foreground text-sm">
                  {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
                </span>
              </div>
              <Button variant="ghost" size="sm">
                <MoreHorizontal className="w-4 h-4" />
              </Button>
            </div>

            {/* Post Content */}
            <h3 className="text-xl font-semibold mb-3 text-foreground">{post.title}</h3>
            <p className="text-muted-foreground mb-4 line-clamp-3">{post.content}</p>
            
            {/* Post Image */}
            {post.imageUrl && (
              <div className="mb-4 rounded-xl overflow-hidden">
                <img 
                  src={post.imageUrl} 
                  alt="Post image"
                  className="w-full h-64 object-cover cursor-pointer hover:scale-105 transition-transform duration-300"
                  onClick={() => {
                    // Open image in modal/full view
                    window.open(post.imageUrl, '_blank');
                  }}
                />
              </div>
            )}

            {/* Post Tags */}
            {post.tags && post.tags.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-4">
                {post.tags.map((tag, index) => (
                  <Badge key={index} variant="secondary" className="text-xs">
                    #{tag}
                  </Badge>
                ))}
              </div>
            )}

            {/* Post Actions */}
            <div className="flex items-center justify-between pt-4 border-t border-border">
              <div className="flex items-center space-x-6">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={handleLike}
                  disabled={likeMutation.isPending}
                  className={cn(
                    "flex items-center space-x-2 transition-colors duration-300",
                    post.isLiked ? "text-red-500 hover:text-red-600" : "text-muted-foreground hover:text-red-500"
                  )}
                >
                  <Heart className={cn("w-4 h-4", post.isLiked && "fill-current")} />
                  <span>{post.likesCount}</span>
                </Button>
                
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => setShowComments(!showComments)}
                  className="flex items-center space-x-2 text-muted-foreground hover:text-crypto-blue transition-colors duration-300"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>{post.commentsCount}</span>
                </Button>
                
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={handleShare}
                  className="flex items-center space-x-2 text-muted-foreground hover:text-crypto-purple transition-colors duration-300"
                >
                  <Share2 className="w-4 h-4" />
                  <span>{post.sharesCount}</span>
                </Button>
              </div>
              
              <div className="flex items-center space-x-2">
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={handleSave}
                  disabled={saveMutation.isPending}
                  className={cn(
                    "transition-colors duration-300",
                    post.isSaved ? "text-crypto-blue" : "text-muted-foreground hover:text-crypto-blue"
                  )}
                >
                  <Bookmark className={cn("w-4 h-4", post.isSaved && "fill-current")} />
                </Button>
                
                <Button className="bg-crypto-gradient hover:opacity-90 text-white">
                  View Details
                </Button>
              </div>
            </div>

            {/* Comments Section */}
            {showComments && (
              <div className="mt-6 pt-6 border-t border-border space-y-4">
                {/* Existing Comments */}
                {post.comments.map((comment) => (
                  <div key={comment.id} className="flex items-start space-x-3">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={comment.user.profileImageUrl || ""} alt={comment.user.firstName || "User"} />
                      <AvatarFallback className="text-xs">
                        {comment.user.firstName?.[0] || comment.user.email?.[0] || "U"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <span className="text-sm font-medium">{comment.user.firstName || "Anonymous"}</span>
                        <span className="text-xs text-muted-foreground">
                          {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground">{comment.content}</p>
                    </div>
                  </div>
                ))}

                {/* Add Comment */}
                <div className="flex items-start space-x-3">
                  <Avatar className="w-8 h-8">
                    <AvatarFallback className="text-xs">U</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 space-y-2">
                    <Textarea
                      placeholder="Write a comment..."
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      className="min-h-[80px] resize-none"
                    />
                    <div className="flex justify-end">
                      <Button 
                        size="sm"
                        onClick={handleComment}
                        disabled={!newComment.trim() || commentMutation.isPending}
                        className="bg-crypto-gradient hover:opacity-90"
                      >
                        <Send className="w-4 h-4 mr-2" />
                        Comment
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
