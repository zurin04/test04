import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Monitor, Smartphone, Globe, LogOut, AlertTriangle } from "lucide-react";

interface Session {
  id: string;
  device: string;
  browser: string;
  location: string;
  lastActive: string;
  current: boolean;
}

export default function SessionManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Mock sessions data - in a real app, this would come from the backend
  const sessions: Session[] = [
    {
      id: "current",
      device: "Desktop",
      browser: "Chrome 120",
      location: "New York, US",
      lastActive: "Just now",
      current: true
    },
    {
      id: "mobile",
      device: "Mobile",
      browser: "Safari iOS",
      location: "New York, US", 
      lastActive: "2 hours ago",
      current: false
    },
    {
      id: "tablet",
      device: "Tablet",
      browser: "Firefox 119",
      location: "Boston, US",
      lastActive: "1 day ago",
      current: false
    }
  ];

  const terminateSessionMutation = useMutation({
    mutationFn: async (sessionId: string) => {
      return await apiRequest(`/api/auth/sessions/${sessionId}`, {
        method: "DELETE",
      });
    },
    onSuccess: () => {
      toast({
        title: "Session terminated",
        description: "The session has been terminated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/sessions"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to terminate session",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    },
  });

  const terminateAllSessionsMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("/api/auth/sessions", {
        method: "DELETE",
      });
    },
    onSuccess: () => {
      toast({
        title: "All sessions terminated",
        description: "All other sessions have been terminated. You'll need to sign in again on other devices.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/sessions"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to terminate sessions",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    },
  });

  const getDeviceIcon = (device: string) => {
    switch (device.toLowerCase()) {
      case "mobile":
        return <Smartphone className="w-5 h-5" />;
      case "tablet":
        return <Monitor className="w-5 h-5" />; 
      default:
        return <Monitor className="w-5 h-5" />;
    }
  };

  const handleTerminateSession = (sessionId: string) => {
    if (confirm("Are you sure you want to terminate this session?")) {
      terminateSessionMutation.mutate(sessionId);
    }
  };

  const handleTerminateAllSessions = () => {
    if (confirm("Are you sure you want to terminate all other sessions? You'll need to sign in again on other devices.")) {
      terminateAllSessionsMutation.mutate();
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            <Globe className="w-5 h-5 mr-2" />
            Active Sessions
          </CardTitle>
          {sessions.filter(s => !s.current).length > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleTerminateAllSessions}
              disabled={terminateAllSessionsMutation.isPending}
              className="text-red-600 hover:text-red-700"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Terminate All Others
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {sessions.map((session) => (
            <div key={session.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="text-muted-foreground">
                  {getDeviceIcon(session.device)}
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <h4 className="font-medium">{session.device}</h4>
                    {session.current && (
                      <Badge variant="outline" className="text-green-600 border-green-600">
                        Current
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {session.browser} • {session.location}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Last active: {session.lastActive}
                  </p>
                </div>
              </div>

              {!session.current && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleTerminateSession(session.id)}
                  disabled={terminateSessionMutation.isPending}
                  className="text-red-600 hover:text-red-700"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Terminate
                </Button>
              )}
            </div>
          ))}
        </div>

        <div className="mt-6 p-4 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
          <div className="flex items-start space-x-2">
            <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5" />
            <div>
              <h4 className="font-medium text-amber-800 dark:text-amber-200">Security Notice</h4>
              <p className="text-sm text-amber-700 dark:text-amber-300 mt-1">
                If you see any sessions you don't recognize, terminate them immediately and consider changing your password.
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}