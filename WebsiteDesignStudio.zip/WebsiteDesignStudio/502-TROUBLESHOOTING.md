# 502 Bad Gateway Troubleshooting Guide

## Quick Fix
If you're experiencing 502 Bad Gateway errors on your VPS deployment, run:

```bash
./manage.sh fix-502
```

This automated tool will diagnose and attempt to fix the most common causes.

## Understanding 502 Errors

A 502 Bad Gateway error occurs when Nginx (the web server) cannot reach your application. This typically means:

1. **Your application isn't running** - Most common cause
2. **Application not responding on port 5000** - Database or startup issues
3. **Nginx configuration problems** - Rare but possible
4. **Environment variable issues** - Missing DATABASE_URL, etc.

## Manual Troubleshooting Steps

### Step 1: Check Application Status
```bash
# Check if PM2 process is running
pm2 status cryptohub

# If not running, start it
pm2 start cryptohub

# Check logs for errors
pm2 logs cryptohub
```

### Step 2: Test Application Response
```bash
# Test if app responds on port 5000
curl http://localhost:5000

# Should return HTML content
# If not, check what's using the port
lsof -i :5000
```

### Step 3: Check Environment Variables
```bash
# Verify database connection string exists
cat .env | grep DATABASE_URL

# Test database connection
PGPASSWORD=$(grep PGPASSWORD .env | cut -d= -f2) \
psql -h localhost -U cryptohub_user -d cryptohub_db -c "SELECT 1;"
```

### Step 4: Verify Build
```bash
# Check if application was built correctly
ls -la dist/index.js

# If missing, rebuild
npm run build
```

### Step 5: Check Nginx
```bash
# Test Nginx configuration
sudo nginx -t

# Check if Nginx is running
sudo systemctl status nginx

# View Nginx error logs
sudo tail -f /var/log/nginx/error.log
```

## Common Fixes

### Fix 1: Application Not Starting
**Symptoms:** PM2 shows app as "errored" or "stopped"

```bash
# Check logs for the error
pm2 logs cryptohub --lines 50

# Common causes:
# - Missing DATABASE_URL
# - Database connection failure
# - Build issues
# - Node.js version mismatch

# Fix missing environment variables
echo "DATABASE_URL=postgresql://cryptohub_user:PASSWORD@localhost:5432/cryptohub_db" >> .env

# Restart application
pm2 restart cryptohub
```

### Fix 2: Database Connection Issues
**Symptoms:** App starts but crashes immediately, logs show database errors

```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Start if needed
sudo systemctl start postgresql

# Test connection manually
sudo -u postgres psql -c "SELECT version();"

# Reset database password if needed
sudo -u postgres psql -c "ALTER USER cryptohub_user PASSWORD 'new_password';"
```

### Fix 3: Port Already in Use
**Symptoms:** App fails to start, logs show "EADDRINUSE"

```bash
# Find what's using port 5000
lsof -i :5000

# Kill the process if safe
sudo kill -9 PROCESS_ID

# Or change the port in your config
echo "PORT=5001" >> .env
# Update Nginx config to proxy to new port
```

### Fix 4: Build Issues
**Symptoms:** dist/index.js missing or outdated

```bash
# Clean and rebuild
rm -rf dist/
npm run build

# Check build output
ls -la dist/

# If build fails, check Node.js version
node --version  # Should be 18+ or 20+
```

### Fix 5: Nginx Configuration
**Symptoms:** Nginx test fails, configuration errors

```bash
# Test configuration
sudo nginx -t

# Common fixes:
# - Fix syntax errors
# - Update proxy_pass URL
# - Check file permissions

# Edit configuration
sudo nano /etc/nginx/sites-available/cryptohub

# Reload after fixes
sudo systemctl reload nginx
```

## Prevention Tips

1. **Monitor Application Health**
   ```bash
   # Run health checks regularly
   ./manage.sh health
   
   # Set up monitoring
   ./manage.sh monitor
   ```

2. **Regular Backups**
   ```bash
   # Create automatic backups
   ./manage.sh backup
   
   # Add to crontab for daily backups
   echo "0 2 * * * cd /var/www/cryptohub && ./manage.sh backup" | sudo crontab -
   ```

3. **Log Monitoring**
   ```bash
   # Check logs regularly
   pm2 logs cryptohub
   sudo tail -f /var/log/nginx/error.log
   ```

4. **Keep System Updated**
   ```bash
   # Update system packages
   sudo apt update && sudo apt upgrade
   
   # Update Node.js packages
   npm update
   ```

## Emergency Recovery

If nothing else works, here's the nuclear option:

```bash
# Stop everything
pm2 stop all
sudo systemctl stop nginx

# Restart services
sudo systemctl start postgresql
sudo systemctl start nginx

# Rebuild and restart application
npm run build
pm2 start ecosystem.config.cjs

# Test the full chain
curl http://localhost:5000
curl http://localhost
```

## Getting Help

If you're still experiencing issues:

1. Run the full diagnostic: `./manage.sh health`
2. Check recent logs: `pm2 logs cryptohub --lines 100`
3. Verify system resources: `df -h` and `free -h`
4. Check Nginx error logs: `sudo tail -n 50 /var/log/nginx/error.log`

The most common cause is simply that the Node.js application isn't running or responding, which the automated fix tool should resolve.