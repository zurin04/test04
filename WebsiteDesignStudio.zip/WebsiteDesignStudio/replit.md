# CryptoHub - Community Platform for Testnets & Airdrops

## Overview

CryptoHub is a modern, full-stack web application designed to facilitate community engagement around cryptocurrency testnets, node setups, social tasks, and airdrop opportunities. The platform serves as a centralized hub where crypto enthusiasts can share knowledge, discover opportunities, and connect with like-minded individuals.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Components**: Radix UI primitives with shadcn/ui components
- **Styling**: Tailwind CSS with custom crypto-themed design tokens
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Authentication**: Replit Auth integration with OpenID Connect
- **Session Management**: Express sessions with PostgreSQL storage
- **API Design**: RESTful API endpoints with proper error handling

### Database Architecture
- **Database**: PostgreSQL with Neon serverless driver
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema Management**: Drizzle Kit for migrations and schema updates
- **Connection**: Connection pooling for optimal performance

## Key Components

### Authentication System
- **Auth Methods**: Email/password and Web3 wallet (MetaMask) authentication
- **Session Storage**: PostgreSQL-backed sessions with configurable TTL
- **Security**: HTTP-only cookies, CSRF protection, secure cookie settings, signature verification for Web3
- **User Management**: Automatic user creation/updates on authentication
- **Web3 Integration**: MetaMask wallet connection with signature-based authentication
- **Role-Based Access**: User roles (user, creator, admin) with different permissions

### Post Management System
- **Categories**: Testnets, Node Setup, Social Tasks, Airdrops
- **Features**: Rich text content, image uploads, tagging system
- **Interactions**: Like, comment, save, and share functionality (all users)
- **Creation**: Restricted to admin and creator roles only
- **Sorting**: Recent, popular, and trending post organization

### User Interaction Features
- **Social Features**: Follow/unfollow users, user profiles
- **Content Curation**: Save posts for later reference
- **Engagement**: Comment system with nested replies
- **Notifications**: Real-time updates for user interactions

### Admin Features
- **Announcements**: System-wide announcement banner
- **Content Moderation**: Post and comment management capabilities
- **User Management**: Admin controls for user accounts
- **Site Settings**: Configurable social media URLs, site name, and platform settings
- **Footer Management**: Dynamic social links displayed based on admin configuration

## Data Flow

### Authentication Flow
1. User initiates login via Replit Auth
2. OIDC flow validates user credentials
3. User session created and stored in PostgreSQL
4. JWT tokens managed automatically by Replit Auth
5. Subsequent requests authenticated via session cookies

### Content Flow
1. Authenticated users create posts with categorization
2. Posts stored in PostgreSQL with full metadata
3. Real-time updates via React Query invalidation
4. Search and filtering applied at database level with URL parameter support
5. Optimistic updates for immediate UI feedback
6. Dynamic footer links based on admin-configured social media URLs

### Image Handling
1. Real image upload with Multer and Sharp processing
2. Automatic image optimization (WebP format, resizing, compression)
3. Profile image upload with camera interface
4. File validation (type, size limits)
5. Secure file storage in uploads directory

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connectivity
- **drizzle-orm**: Type-safe database operations
- **@tanstack/react-query**: Server state management
- **express**: Web application framework
- **passport**: Authentication middleware

### UI Dependencies
- **@radix-ui/***: Accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **lucide-react**: Icon library
- **date-fns**: Date manipulation utilities

### Development Dependencies
- **vite**: Build tool and development server
- **typescript**: Type checking and compilation
- **eslint**: Code linting and formatting

## Deployment Strategy

### Build Process
1. **Frontend**: Vite builds React application to `dist/public`
2. **Backend**: esbuild bundles server code to `dist/index.js`
3. **Database**: Drizzle migrations applied via `db:push` command

### Environment Configuration
- **Development**: Uses Vite dev server with HMR
- **Production**: Serves static files from Express with optimized builds
- **Database**: Requires `DATABASE_URL` environment variable
- **Auth**: Requires Replit-specific environment variables

### Hosting Requirements
- Node.js 18+ runtime environment
- PostgreSQL database (Neon serverless recommended)
- Environment variables for database and authentication
- SSL/HTTPS for secure cookie handling

## Recent Changes
- July 1, 2025: Fixed VPS deployment REPLIT_DOMAINS error and completed single-script solution:
  - Made Replit Auth optional for VPS deployments by conditionally loading OIDC configuration
  - Modified replitAuth.ts to gracefully handle missing REPLIT_DOMAINS environment variable
  - Updated deploy.sh to work without Replit-specific environment variables
  - Replaced complex multi-file deployment system with single deploy.sh script
  - All-in-one deployment: installs dependencies, configures database, builds app, sets up web server
  - Proper PM2 configuration using dist/index.js for production
  - Built-in 502 troubleshooting with fix-502.sh helper script
  - Reliable HTTP status code testing to prevent false warnings
  - Clean, streamlined deployment process with clear progress indicators
  - Fixed PostgreSQL database connection issues in development environment
- July 1, 2025: Comprehensive platform enhancements implemented:
  - Real-time notification system with user interaction tracking
  - Advanced search and filtering with date ranges, categories, and tags
  - Content moderation panel for admin users with reporting system
  - Analytics dashboard with user growth, engagement, and content metrics
  - User onboarding tour for improved new user experience
  - Live activity feed showing real-time platform interactions
  - Enhanced authentication with better error handling and session management
  - Automatic notification creation for likes, comments, and follows
  - Complete database schema with notifications table
  - Performance optimizations and loading states throughout
- June 30, 2025: Fixed DATABASE_URL connection issue - PostgreSQL database properly configured
- June 30, 2025: Added missing footer links functionality with proper routing
- June 30, 2025: Implemented Guidelines, FAQ, Support, API Documentation, Tutorials, and Blog pages
- June 30, 2025: Added dynamic social media links in footer using site settings
- June 30, 2025: Enhanced search functionality with URL parameter support
- June 30, 2025: Created comprehensive site footer component with admin-configurable social links
- June 30, 2025: Implemented comprehensive authentication system with traditional sign up/sign in
- June 30, 2025: Added Web3 wallet authentication with MetaMask integration
- June 30, 2025: Created modern authentication UI with form validation and error handling
- June 30, 2025: Fixed Web3 authentication routing and backend integration
- June 30, 2025: Added comprehensive user profile management and settings interface
- June 30, 2025: Enabled signature verification bypass for development testing
- June 30, 2025: Removed Replit authentication and simplified to email/Web3 only
- June 30, 2025: Restricted post creation to admin and creator roles only
- June 30, 2025: Added real image upload functionality with Sharp processing
- June 30, 2025: Implemented profile image upload with automatic resizing and optimization

## Changelog
- June 30, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.